# FAQ
## 1 sysmetcec杀软问题
截图1  
<center class="half">
    <img src="./symantec-1.png" width="400"/>
</center>
截图2  
<center class="half">
    <img src="./symantec-2.png" width="400"/>
</center>
处理办法：  
[链接](https://www.cnblogs.com/javabluesky/archive/2011/08/26/2211469.html)
