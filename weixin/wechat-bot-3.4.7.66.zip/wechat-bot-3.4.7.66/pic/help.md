# Change Log
## version 3.4.7.66(2020-05-24)
### Feature
* 希望可以增加发送文件的功能,closes #28

## version 3.3.7.66(2020-5-14)
### Feature
* send the pic via http feature,closes #48
* get the member id from chatroom,closes #49
* get the nick of chatroom member,closes #50
* send the at msg via http ,closes #51

## version 2.9.7.66(2020-05-12)
### Feature
* get the contact list via http ,closes #47
## version 2.8.7.66(2020-05-12)
### Bug Fixes
* the sender or receiver is incomplete when receive the pic,closes #44
### enhancement
* 新增自动通过新朋友申请接口，能获取新朋友的用户信息,closes #40
* the sender or receiver is incomplete when receive the text message，closes #45
## version 2.8.5.65(2020-05-10)
### Feature
* http support,closes #35
* send the text message via http,#43
## version 2.6.5.65(2020-05-09)
### Bug Fixes
* 群聊记录中wxid和sender填反的问题,closes #41  
  更改了消息体里面的wxid为receiver  
* 微信发送消息失败 ,closes #21

## version 2.6.4.63(2020-05-02)
### Bug Fixes
* op:personal info is no return,closes #38
### Feature
* receive the pic,closes #25

## version 2.5.4.62(2020-05-01)
### Bug Fixes
* get the nickname can cause the program to crash,closes #37

## version 2.5.4.61(2020-04-27)
bugfix:  
#32  
## version 2.5.4.60（2020-04-25)
bugfix:  
#31  
#33  
enhanced:  
#34  

## version 2.5.3.58(2020-04-13)
bugfix:  
#23  
#24  
## version2.5.3.56（2020-04-04)
bugfix:#22

## version 2.5.2.56(2020-03-29)
new feature:  
#20 get nickname of chatroom member  
## version 2.2.2.56(2020-03-05)
new feature:  
#10   get personal infomation  
#12   debug switch  
enhanced:  
#11 catch more exception  

## version 2.0.1.55(2020-03-02)
new feature:wechat urgrade to 2.8.0.121  
bugfix:#9  

## version 1.5.1.53(2020-03-01)
new feature:#7  
enhanced:  
1、pic msg optimized  
2、txt msg optimized  
3、user list msg optimized  

## version 1.2.1.52(2020-02-28)
new feature:get chatroom member list  
bugfix:random carsh(#6)  

## version 1.1.1.51(2020-02-27)
new feature:send at msg

## version 1.0.1.50 (2020-02-21)
bugfix:incompelete list bugfixed(#5)



## version 1.0.0.50 (2020-02-19)
new feature:send pic message

## version 1.0.0.00（2020-02-18)
new feature:websocket server  
new feature:send txt message  
new feature:get user list  
new feature:receive the wechat txt message  
