# 项目依赖
1：maven  
2：Spring Boot  
3：Java-WebSocket  
4：由于本人比较懒用了lombok，需要在IDE中安装lombok插件  

启动  
1：修改src\main\resources\application.yml 中微信的url  
2：将  src\main\java\pro\mickey\wechatpush\service\TestService.java  中的ID改为你的发送人的微信ID即可  
 
