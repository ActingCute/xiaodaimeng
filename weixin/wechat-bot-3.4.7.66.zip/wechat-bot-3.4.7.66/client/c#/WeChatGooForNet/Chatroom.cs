﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebliskey.WeChatGooForNet
{
    public class Chatroom
    {
        public string ChatroomId { get; set; }
        public string NickName { get; set; }
        public string WeChatId { get; set; }

    }
}
