
# 使用说明
## 代码库
[github获取相关程序](https://github.com/cixingguangming55555/wechat-bot "github获取相关程序")
1、server目录  服务端程序及工具
2、client目录  客户端程序
## 环境准备
1、必须是微信PC  
2、版本必须是2.8.0.121，[微信2.8.0.121传送门](https://pan.baidu.com/s/1LoV9wc1XaJMX1O6uLcxq1Q "微信2.8.0.121传送门"),提取码：d96z
## 启动微信
1、请在windows下启动PC微信，并成功登录
## 开启服务端
1、打开微信DLL注入器，如图
![启动机器人服务](https://www.showdoc.cc/server/api/common/visitfile/sign/4c1d3698dba487adb2ae9af9e41451a8?showdoc=.jpg)

2、点击注入DLL即可
## 开启客户端
可以使用提供的C++客户端和JS客户端进行测试
